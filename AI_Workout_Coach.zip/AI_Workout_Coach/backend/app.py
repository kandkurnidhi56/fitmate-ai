from flask import Flask, request, jsonify
import json
import os
from workout_generator import generate_workout, save_feedback

app = Flask(__name__)


@app.route("/")
def home():
    return jsonify({
        "message": "AI Workout Coach Backend is Running!"
    })


@app.route("/generate-workout", methods=["POST"])
def create_workout():

    data = request.json

    free_time = data.get("free_time")
    difficulty = data.get("difficulty")
    goal = data.get("goal")
    equipment = data.get("equipment", "none")

    if free_time is None or difficulty is None or goal is None:
        return jsonify({
            "error": "Please provide free_time, difficulty and goal"
        }), 400

    try:
        free_time = int(free_time)
    except (ValueError, TypeError):
        return jsonify({
            "error": "Free time must be a number"
        }), 400

    if free_time <= 0:
        return jsonify({
            "error": "Free time must be greater than 0"
        }), 400

    valid_difficulties = ["beginner", "intermediate"]

    if difficulty not in valid_difficulties:
        return jsonify({
            "error": "Invalid difficulty"
        }), 400

    valid_goals = ["weight_loss", "strength"]

    if goal not in valid_goals:
        return jsonify({
            "error": "Invalid goal"
        }), 400

    valid_equipment = ["none", "dumbbells", "resistance_band"]

    if equipment not in valid_equipment:
        return jsonify({
            "error": "Invalid equipment"
        }), 400

    workout = generate_workout(
        free_time,
        difficulty,
        goal,
        equipment
    )

    return jsonify(workout)


@app.route("/history", methods=["GET"])
def history():

    history_path = os.path.join(
        os.path.dirname(__file__),
        "..",
        "data",
        "history.json"
    )

    with open(history_path, "r") as file:
        history = json.load(file)

    return jsonify(history)

    data = request.json
    rating = data.get("rating")

    if rating is None:
        return jsonify({
            "error": "Please provide a rating"
        }), 400

    if rating < 1 or rating > 5:
        return jsonify({
            "error": "Rating must be between 1 and 5"
        }), 400

    save_feedback(rating)

    return jsonify({
        "message": "Feedback saved successfully",
        "rating": rating
    })

@app.route("/feedback", methods=["POST"])
def feedback():

    data = request.json
    rating = data.get("rating")

    if rating is None:
        return jsonify({
            "error": "Please provide a rating"
        }), 400

    if rating < 1 or rating > 5:
        return jsonify({
            "error": "Rating must be between 1 and 5"
        }), 400

    save_feedback(rating)

    return jsonify({
        "message": "Feedback saved successfully",
        "rating": rating
    })
if __name__ == "__main__":
    app.run(debug=True)