import json
import os
import random
from datetime import datetime


def save_feedback(rating):
    history_path = os.path.join(os.path.dirname(__file__), "..", "data", "history.json")

    with open(history_path, "r") as file:
        history = json.load(file)

    history.append({
        "type": "feedback",
        "rating": rating,
        "date": datetime.now().isoformat()
    })

    with open(history_path, "w") as file:
        json.dump(history, file, indent=4)


def get_adaptive_difficulty(difficulty):
    history_path = os.path.join(os.path.dirname(__file__), "..", "data", "history.json")

    with open(history_path, "r") as file:
        history = json.load(file)

    feedback_history = [
        item for item in history
        if item.get("type") == "feedback"
    ]

    if not feedback_history:
        return difficulty

    latest_rating = feedback_history[-1]["rating"]

    levels = ["beginner", "intermediate"]
    current_index = levels.index(difficulty)

    if latest_rating <= 2:
        current_index = max(0, current_index - 1)
    elif latest_rating >= 4:
        current_index = min(len(levels) - 1, current_index + 1)

    return levels[current_index]


def load_exercises():
    file_path = os.path.join(os.path.dirname(__file__), "..", "data", "exercises.json")

    with open(file_path, "r") as file:
        return json.load(file)


def save_workout_history(workout):
    history_path = os.path.join(os.path.dirname(__file__), "..", "data", "history.json")

    with open(history_path, "r") as file:
        history = json.load(file)

    history.append({
        "type": "workout",
        "workout": workout,
        "date": datetime.now().isoformat()
    })

    with open(history_path, "w") as file:
        json.dump(history, file, indent=4)


def generate_workout(free_time, difficulty, goal, equipment):

    difficulty = get_adaptive_difficulty(difficulty)
    exercises = load_exercises()

    suitable_exercises = [
        exercise for exercise in exercises
        if exercise["difficulty"] == difficulty
        and exercise["goal"] == goal
        and exercise["equipment"] == equipment
    ]

    if not suitable_exercises:
        suitable_exercises = [
            exercise for exercise in exercises
            if exercise["difficulty"] == difficulty
            and exercise["equipment"] == equipment
        ]

    random.shuffle(suitable_exercises)

    workout = []
    total_time = 0

    while suitable_exercises:
        possible_exercises = [
            exercise for exercise in suitable_exercises
            if total_time + exercise["duration"] <= free_time
        ]

        if not possible_exercises:
            break

        exercise = possible_exercises[0]

        workout.append(exercise)
        suitable_exercises.remove(exercise)
        total_time += exercise["duration"]

        if total_time >= free_time - 1:
            break

    explanation = "Workout created based on your available time, goal, difficulty and equipment."

    history_path = os.path.join(os.path.dirname(__file__), "..", "data", "history.json")

    with open(history_path, "r") as file:
        history = json.load(file)

    feedback_history = [
        item for item in history
        if item.get("type") == "feedback"
    ]

    if feedback_history:
        latest_rating = feedback_history[-1]["rating"]

        if latest_rating <= 2:
            explanation = "Your previous rating was low, so the workout was adjusted to be easier."
        elif latest_rating >= 4:
            explanation = "Your previous rating was high, so the workout was adjusted to be more challenging."
        else:
            explanation = "Your previous rating was neutral, so the workout difficulty was kept similar."

    result = {
        "workout": workout,
        "total_time": total_time,
        "available_time": free_time,
        "explanation": explanation,
        "safety_message": "Stop if you feel pain or discomfort. Choose exercises appropriate for your fitness level."
    }

    save_workout_history(result)

    return result