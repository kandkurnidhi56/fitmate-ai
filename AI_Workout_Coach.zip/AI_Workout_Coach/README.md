# AI Workout Coach

Project files are organized into these areas:

- `backend/` - application and API logic
- `frontend/` - user interface
- `data/` - workout and related data
